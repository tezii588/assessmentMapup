/**
 * Parser utility to convert JSON trip events into usable timeline and coordinate data.
 * Handles event transformation and timeline generation for visualization.
 */

export interface TripEvent {
  timestamp: string
  type: string
  lat: number
  lng: number
  event_text: string
}

export interface TripData {
  trip_id: string
  trip_name: string
  vehicle_id: string
  status: "active" | "completed" | "cancelled" | "issue"
  start_time: string
  end_time: string | null
  total_distance_km: number
  average_speed_kmh: number
  fuel_consumed_liters: number
  events: TripEvent[]
}

export interface TimelineEntry {
  index: number
  timestamp: string
  type: string
  lat: number
  lng: number
  event_text: string
  progress_percent: number
}

export interface Coordinate {
  lat: number
  lng: number
  timestamp: string
}

/**
 * Parse raw trip JSON to extract timeline and coordinate data.
 * @param tripData - Raw trip data from JSON
 * @returns Object with timeline, coordinates, and metadata
 */
export function parseTripData(tripData: TripData) {
  const timeline: TimelineEntry[] = tripData.events.map((event, index) => ({
    index,
    timestamp: event.timestamp,
    type: event.type,
    lat: event.lat,
    lng: event.lng,
    event_text: event.text,
    progress_percent: ((index + 1) / tripData.events.length) * 100,
  }))

  const coordinates: Coordinate[] = tripData.events.map((event) => ({
    lat: event.lat,
    lng: event.lng,
    timestamp: event.timestamp,
  }))

  return {
    timeline,
    coordinates,
    totalEvents: tripData.events.length,
    tripMetadata: {
      id: tripData.trip_id,
      name: tripData.trip_name,
      vehicleId: tripData.vehicle_id,
      status: tripData.status,
      startTime: tripData.start_time,
      endTime: tripData.end_time,
      totalDistanceKm: tripData.total_distance_km,
      averageSpeedKmh: tripData.average_speed_kmh,
      fuelConsumedLiters: tripData.fuel_consumed_liters,
    },
  }
}

/**
 * Get route coordinates (lat/lng pairs) for polyline rendering on map
 */
export function getRouteCoordinates(tripData: TripData): [number, number][] {
  return tripData.events.map((event) => [event.lat, event.lng])
}

/**
 * Calculate bounding box for map fitting
 */
export function calculateBounds(coordinates: [number, number][]): [[number, number], [number, number]] {
  const lats = coordinates.map((c) => c[0])
  const lngs = coordinates.map((c) => c[1])
  const minLat = Math.min(...lats)
  const maxLat = Math.max(...lats)
  const minLng = Math.min(...lngs)
  const maxLng = Math.max(...lngs)
  return [
    [minLat, minLng],
    [maxLat, maxLng],
  ]
}

/**
 * Get status badge properties
 */
export function getStatusBadge(status: string) {
  const statusMap: Record<string, { label: string; color: string; bgColor: string }> = {
    active: { label: "Active", color: "text-green-700", bgColor: "bg-green-100" },
    completed: {
      label: "Completed",
      color: "text-blue-700",
      bgColor: "bg-blue-100",
    },
    cancelled: {
      label: "Cancelled",
      color: "text-red-700",
      bgColor: "bg-red-100",
    },
    issue: { label: "Issue", color: "text-yellow-700", bgColor: "bg-yellow-100" },
  }

  return statusMap[status] || statusMap.active
}
