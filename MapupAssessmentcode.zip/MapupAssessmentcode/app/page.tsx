"use client"

import { useState } from "react"
import { TripList } from "@/app/components/TripList"
import { TripMap } from "@/app/components/TripMap"
import { TripDetails } from "@/app/components/TripDetails"
import { useSimulator } from "@/app/hooks/useSimulator"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Play, Pause, RotateCcw, MapPin, Truck } from "lucide-react"
import type { TripData } from "@/app/utils/parser"

export default function Dashboard() {
  const [selectedTrip, setSelectedTrip] = useState<TripData | null>(null)
  const [selectedTripId, setSelectedTripId] = useState<string | null>(null)

  const { state, togglePlayPause, changeSpeed, reset } = useSimulator(selectedTrip)

  const handleSelectTrip = (trip: TripData) => {
    setSelectedTrip(trip)
    setSelectedTripId(trip.trip_id)
    reset()
  }

  return (
    <div className="h-screen w-screen flex flex-col bg-background">
      {/* Premium Header */}
      <header className="border-b border-border bg-gradient-to-r from-card to-card/50 backdrop-blur-sm px-6 py-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-gradient-to-br from-primary to-primary/80 rounded-lg shadow-lg">
              <Truck className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Fleet Tracking Dashboard</h1>
              <p className="text-sm text-muted-foreground">Real-time vehicle simulation & analytics</p>
            </div>
          </div>
          <div className="text-xs text-muted-foreground px-3 py-1 bg-muted rounded-full">MapUp Assessment</div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 overflow-hidden flex gap-4 p-4">
        {/* Sidebar - Trip List */}
        <div className="w-80 flex flex-col gap-3">
          <Card className="p-4 border-border/50 bg-card/40 backdrop-blur">
            <div className="flex items-center gap-2 mb-2">
              <MapPin className="w-4 h-4 text-primary" />
              <h2 className="text-lg font-bold">Active Trips</h2>
            </div>
            <p className="text-xs text-muted-foreground">Select a trip to monitor</p>
          </Card>
          <Card className="flex-1 overflow-hidden p-3 border-border/50 bg-card/40 backdrop-blur">
            <TripList onSelectTrip={handleSelectTrip} selectedTripId={selectedTripId} />
          </Card>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col gap-3 overflow-hidden">
          {/* Simulation Controls */}
          <Card className="p-4 border-border/50 bg-card/40 backdrop-blur">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-3 flex-1">
                <Button
                  onClick={togglePlayPause}
                  variant={state.isPlaying ? "default" : "outline"}
                  size="sm"
                  className="gap-2"
                >
                  {state.isPlaying ? (
                    <>
                      <Pause className="w-4 h-4" />
                      Pause
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4" />
                      Play
                    </>
                  )}
                </Button>

                <Button onClick={reset} variant="outline" size="sm" className="gap-2">
                  <RotateCcw className="w-4 h-4" />
                  Reset
                </Button>

                {/* Speed Controls */}
                <div className="flex gap-1 ml-auto">
                  {[1, 5, 10].map((speed) => (
                    <Button
                      key={speed}
                      onClick={() => changeSpeed(speed as 1 | 5 | 10)}
                      variant={state.speed === speed ? "default" : "outline"}
                      size="sm"
                      className="w-14 font-semibold"
                    >
                      {speed}x
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          </Card>

          {/* Map and Details Grid */}
          <div className="flex-1 grid grid-cols-4 gap-3 overflow-hidden">
            {/* Map */}
            <div className="col-span-3">
              <Card className="h-full p-4 border-border/50 bg-card/40 backdrop-blur overflow-hidden">
                {selectedTrip ? (
                  <TripMap tripData={selectedTrip} currentLat={state.currentLat} currentLng={state.currentLng} />
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-muted-foreground gap-2">
                    <MapPin className="w-8 h-8 opacity-50" />
                    <p className="text-sm">Select a trip to view map</p>
                  </div>
                )}
              </Card>
            </div>

            {/* Details Panel */}
            <div className="col-span-1 overflow-hidden">
              <TripDetails
                tripData={selectedTrip}
                currentEventIndex={state.currentEventIndex}
                percentComplete={state.percentComplete}
                lastEventText={state.lastEventText}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
