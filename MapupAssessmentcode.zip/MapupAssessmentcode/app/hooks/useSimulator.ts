"use client"

import { useState, useEffect, useRef, useCallback } from "react"
import type { TripData } from "@/app/utils/parser"

export interface SimulationState {
  currentEventIndex: number
  isPlaying: boolean
  speed: 1 | 5 | 10
  percentComplete: number
  currentLat: number
  currentLng: number
  lastEventText: string
}

/**
 * useSimulator hook manages real-time event simulation for trips.
 * Efficiently processes events incrementally at configurable speeds (1x, 5x, 10x).
 *
 * Integration notes:
 * - Later, replace the local event loop with WebSocket for live data:
 *   const socket = new WebSocket('wss://api.example.com/trips/live')
 *   socket.on('event', (event) => processEvent(event))
 * - Or use polling: setInterval(() => fetchLatestEvents(), pollInterval)
 */
export function useSimulator(tripData: TripData | null) {
  const [state, setState] = useState<SimulationState>({
    currentEventIndex: 0,
    isPlaying: false,
    speed: 1,
    percentComplete: 0,
    currentLat: tripData?.events[0]?.lat || 0,
    currentLng: tripData?.events[0]?.lng || 0,
    lastEventText: tripData?.events[0]?.event_text || "Ready",
  })

  const animationFrameRef = useRef<number | null>(null)
  const lastUpdateRef = useRef<number>(Date.now())

  const processEvent = useCallback(
    (eventIndex: number) => {
      if (!tripData || eventIndex >= tripData.events.length) return

      const event = tripData.events[eventIndex]
      const progress = ((eventIndex + 1) / tripData.events.length) * 100

      setState((prev) => ({
        ...prev,
        currentEventIndex: eventIndex,
        currentLat: event.lat,
        currentLng: event.lng,
        lastEventText: event.event_text,
        percentComplete: progress,
      }))
    },
    [tripData],
  )

  const togglePlayPause = useCallback(() => {
    setState((prev) => ({ ...prev, isPlaying: !prev.isPlaying }))
  }, [])

  const changeSpeed = useCallback((speed: 1 | 5 | 10) => {
    setState((prev) => ({ ...prev, speed }))
  }, [])

  const reset = useCallback(() => {
    setState((prev) => ({
      ...prev,
      currentEventIndex: 0,
      isPlaying: false,
      percentComplete: 0,
      currentLat: tripData?.events[0]?.lat || 0,
      currentLng: tripData?.events[0]?.lng || 0,
      lastEventText: tripData?.events[0]?.event_text || "Ready",
    }))
  }, [tripData])

  // Main simulation loop
  useEffect(() => {
    if (!state.isPlaying || !tripData) {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
      }
      return
    }

    const updateLoop = () => {
      const now = Date.now()
      const deltaTime = now - lastUpdateRef.current

      // Speed multipliers: 1x = 100ms per event, 5x = 20ms, 10x = 10ms
      const delayPerEvent = 100 / state.speed
      if (deltaTime >= delayPerEvent) {
        if (state.currentEventIndex < tripData.events.length - 1) {
          processEvent(state.currentEventIndex + 1)
          lastUpdateRef.current = now
        } else {
          setState((prev) => ({ ...prev, isPlaying: false }))
        }
      }

      animationFrameRef.current = requestAnimationFrame(updateLoop)
    }

    lastUpdateRef.current = Date.now()
    animationFrameRef.current = requestAnimationFrame(updateLoop)

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
      }
    }
  }, [state.isPlaying, state.currentEventIndex, state.speed, tripData, processEvent])

  return {
    state,
    togglePlayPause,
    changeSpeed,
    reset,
  }
}
