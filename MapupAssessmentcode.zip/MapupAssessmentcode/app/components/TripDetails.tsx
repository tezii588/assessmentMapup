"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { type TripData, getStatusBadge } from "@/app/utils/parser"
import { Clock, Gauge, Fuel, Zap, MapPin } from "lucide-react"

interface TripDetailsProps {
  tripData: TripData | null
  currentEventIndex: number
  percentComplete: number
  lastEventText: string
}

export function TripDetails({ tripData, currentEventIndex, percentComplete, lastEventText }: TripDetailsProps) {
  if (!tripData) {
    return (
      <Card className="h-full border-border/50 bg-card/40 backdrop-blur flex flex-col items-center justify-center">
        <MapPin className="w-8 h-8 text-muted-foreground/50 mb-2" />
        <p className="text-xs text-muted-foreground text-center">Select a trip to view details</p>
      </Card>
    )
  }

  const statusBadge = getStatusBadge(tripData.status)
  const startDate = new Date(tripData.start_time)
  const endDate = tripData.end_time ? new Date(tripData.end_time) : null
  const durationHours = endDate ? (endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60) : null

  return (
    <Card className="h-full flex flex-col border-border/50 bg-card/40 backdrop-blur overflow-hidden">
      <CardHeader className="pb-3">
        <div className="space-y-2">
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1 min-w-0">
              <CardTitle className="text-base line-clamp-1">{tripData.trip_name}</CardTitle>
              <CardDescription className="text-xs">{tripData.vehicle_id}</CardDescription>
            </div>
            <Badge className={`${statusBadge.bgColor} ${statusBadge.color} text-xs`}>{statusBadge.label}</Badge>
          </div>
        </div>
      </CardHeader>

      <CardContent className="flex-1 overflow-y-auto space-y-4 text-sm">
        {/* Progress Bar */}
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="font-medium text-xs">Progress</span>
            <span className="text-xs text-muted-foreground font-mono">{Math.round(percentComplete)}%</span>
          </div>
          <div className="w-full bg-secondary rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-gradient-to-r from-primary to-primary/60 h-full rounded-full transition-all"
              style={{ width: `${percentComplete}%` }}
            />
          </div>
          <div className="text-xs text-muted-foreground">
            Event {currentEventIndex + 1} / {tripData.events.length}
          </div>
        </div>

        {/* Current Event */}
        <div className="bg-muted/40 border border-border/50 p-2.5 rounded-lg">
          <div className="text-xs font-medium mb-1 text-foreground">Current Event</div>
          <div className="text-xs text-muted-foreground line-clamp-2">{lastEventText}</div>
        </div>

        {/* Trip Metrics */}
        <div className="space-y-2.5 pt-2">
          <div className="flex items-center gap-3">
            <MapPin className="w-4 h-4 text-muted-foreground flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <div className="text-xs text-muted-foreground">Distance</div>
              <div className="font-semibold text-sm">{tripData.total_distance_km} km</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Gauge className="w-4 h-4 text-muted-foreground flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <div className="text-xs text-muted-foreground">Avg Speed</div>
              <div className="font-semibold text-sm">{tripData.average_speed_kmh} km/h</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Fuel className="w-4 h-4 text-muted-foreground flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <div className="text-xs text-muted-foreground">Fuel</div>
              <div className="font-semibold text-sm">{tripData.fuel_consumed_liters} L</div>
            </div>
          </div>

          {durationHours && (
            <div className="flex items-center gap-3">
              <Clock className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="text-xs text-muted-foreground">Duration</div>
                <div className="font-semibold text-sm">{durationHours.toFixed(1)}h</div>
              </div>
            </div>
          )}

          <div className="flex items-center gap-3">
            <Zap className="w-4 h-4 text-muted-foreground flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <div className="text-xs text-muted-foreground">Events</div>
              <div className="font-semibold text-sm">{tripData.events.length}</div>
            </div>
          </div>
        </div>

        {/* Event Feed */}
        <div className="space-y-2 pt-2 border-t border-border/50">
          <div className="text-xs font-medium text-foreground">Recent Events</div>
          <div className="space-y-1.5 max-h-32 overflow-y-auto">
            {tripData.events.slice(Math.max(0, currentEventIndex - 3), currentEventIndex + 1).map((event, idx) => (
              <div key={idx} className="text-xs p-2 bg-muted/40 border border-border/50 rounded-md">
                <div className="font-medium text-foreground">{event.event_text}</div>
                <div className="text-muted-foreground text-xs">{new Date(event.timestamp).toLocaleTimeString()}</div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
