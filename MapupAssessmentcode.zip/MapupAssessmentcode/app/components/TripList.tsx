"use client"

import { useState, useEffect } from "react"
import { type TripData, getStatusBadge } from "@/app/utils/parser"
import { Loader2 } from "lucide-react"

interface TripListProps {
  onSelectTrip: (trip: TripData) => void
  selectedTripId: string | null
}

export function TripList({ onSelectTrip, selectedTripId }: TripListProps) {
  const [trips, setTrips] = useState<TripData[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function loadTrips() {
      try {
        const tripIds = [
          "trip_1_cross_country",
          "trip_2_urban_dense",
          "trip_3_mountain_cancelled",
          "trip_4_southern_technical",
          "trip_5_regional_logistics",
        ]

        const loadedTrips = await Promise.all(tripIds.map((id) => fetch(`/data/${id}.json`).then((res) => res.json())))

        setTrips(loadedTrips)
      } catch (error) {
        console.error("Error loading trips:", error)
      } finally {
        setLoading(false)
      }
    }

    loadTrips()
  }, [])

  if (loading) {
    return (
      <div className="h-full flex items-center justify-center text-muted-foreground">
        <Loader2 className="w-5 h-5 animate-spin" />
      </div>
    )
  }

  return (
    <div className="space-y-2 overflow-y-auto h-full pr-2">
      {trips.map((trip) => {
        const statusBadge = getStatusBadge(trip.status)
        const isSelected = selectedTripId === trip.trip_id

        return (
          <button
            key={trip.trip_id}
            onClick={() => onSelectTrip(trip)}
            className={`w-full text-left transition-all rounded-lg p-3 border ${
              isSelected
                ? "bg-primary/15 border-primary text-foreground"
                : "bg-card/50 hover:bg-card/80 border-border/50 text-foreground"
            }`}
          >
            <div className="space-y-1.5">
              <div className="font-semibold text-sm line-clamp-1">{trip.trip_name}</div>
              <div className="text-xs text-muted-foreground line-clamp-1">{trip.vehicle_id}</div>
              <div className="flex items-center gap-2 pt-1">
                <span
                  className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusBadge.bgColor} ${statusBadge.color}`}
                >
                  {statusBadge.label}
                </span>
                <span className="text-xs text-muted-foreground">{trip.total_distance_km} km</span>
              </div>
            </div>
          </button>
        )
      })}
    </div>
  )
}
