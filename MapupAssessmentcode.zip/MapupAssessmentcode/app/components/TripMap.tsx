"use client"

import { useEffect, useRef } from "react"
import type { TripData } from "@/app/utils/parser"
import { getRouteCoordinates, calculateBounds } from "@/app/utils/parser"

interface TripMapProps {
  tripData: TripData | null
  currentLat: number
  currentLng: number
}

export function TripMap({ tripData, currentLat, currentLng }: TripMapProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!canvasRef.current || !containerRef.current || !tripData) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas size to match container
    const rect = containerRef.current.getBoundingClientRect()
    canvas.width = rect.width
    canvas.height = rect.height

    // Get route coordinates
    const coordinates = getRouteCoordinates(tripData)
    if (coordinates.length === 0) return

    // Calculate bounds
    const bounds = calculateBounds(coordinates)
    const padding = 40

    // Calculate scale and offset
    const mapWidth = bounds.maxLng - bounds.minLng
    const mapHeight = bounds.maxLat - bounds.minLat
    const scaleX = (canvas.width - padding * 2) / mapWidth
    const scaleY = (canvas.height - padding * 2) / mapHeight
    const scale = Math.min(scaleX, scaleY)

    const offsetX = padding - bounds.minLng * scale
    const offsetY = canvas.height - padding - bounds.minLat * scale

    // Clear canvas
    ctx.fillStyle = "rgb(20, 20, 25)"
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    // Draw grid
    ctx.strokeStyle = "rgba(100, 100, 120, 0.1)"
    ctx.lineWidth = 1
    for (let i = 0; i < canvas.width; i += 50) {
      ctx.beginPath()
      ctx.moveTo(i, 0)
      ctx.lineTo(i, canvas.height)
      ctx.stroke()
    }
    for (let i = 0; i < canvas.height; i += 50) {
      ctx.beginPath()
      ctx.moveTo(0, i)
      ctx.lineTo(canvas.width, i)
      ctx.stroke()
    }

    // Draw route polyline
    ctx.strokeStyle = "rgb(59, 130, 246)"
    ctx.lineWidth = 3
    ctx.lineCap = "round"
    ctx.lineJoin = "round"
    ctx.beginPath()

    coordinates.forEach((coord, idx) => {
      const x = coord[1] * scale + offsetX
      const y = offsetY - coord[0] * scale
      if (idx === 0) ctx.moveTo(x, y)
      else ctx.lineTo(x, y)
    })
    ctx.stroke()

    // Draw waypoints
    ctx.fillStyle = "rgba(59, 130, 246, 0.3)"
    coordinates.forEach((coord) => {
      const x = coord[1] * scale + offsetX
      const y = offsetY - coord[0] * scale
      ctx.beginPath()
      ctx.arc(x, y, 4, 0, Math.PI * 2)
      ctx.fill()
    })

    // Draw start point
    const startX = coordinates[0][1] * scale + offsetX
    const startY = offsetY - coordinates[0][0] * scale
    ctx.fillStyle = "rgb(34, 197, 94)"
    ctx.beginPath()
    ctx.arc(startX, startY, 7, 0, Math.PI * 2)
    ctx.fill()

    // Draw end point
    const endX = coordinates[coordinates.length - 1][1] * scale + offsetX
    const endY = offsetY - coordinates[coordinates.length - 1][0] * scale
    ctx.fillStyle = "rgb(239, 68, 68)"
    ctx.beginPath()
    ctx.arc(endX, endY, 7, 0, Math.PI * 2)
    ctx.fill()

    // Draw current position
    const currentX = currentLng * scale + offsetX
    const currentY = offsetY - currentLat * scale
    ctx.fillStyle = "rgb(249, 115, 22)"
    ctx.beginPath()
    ctx.arc(currentX, currentY, 6, 0, Math.PI * 2)
    ctx.fill()

    // Draw pulse animation around current position
    ctx.strokeStyle = "rgba(249, 115, 22, 0.3)"
    ctx.lineWidth = 2
    const pulse = (Date.now() % 1000) / 1000
    ctx.beginPath()
    ctx.arc(currentX, currentY, 6 + pulse * 15, 0, Math.PI * 2)
    ctx.stroke()

    // Draw legend
    const legendY = 20
    const legendX = canvas.width - 180
    ctx.fillStyle = "rgba(20, 20, 25, 0.8)"
    ctx.fillRect(legendX - 10, legendY - 10, 180, 110)
    ctx.strokeStyle = "rgba(100, 100, 120, 0.3)"
    ctx.lineWidth = 1
    ctx.strokeRect(legendX - 10, legendY - 10, 180, 110)

    ctx.fillStyle = "rgb(200, 200, 200)"
    ctx.font = "12px sans-serif"
    ctx.fillText("Legend", legendX, legendY + 12)

    ctx.fillStyle = "rgb(34, 197, 94)"
    ctx.beginPath()
    ctx.arc(legendX + 5, legendY + 28, 3, 0, Math.PI * 2)
    ctx.fill()
    ctx.fillStyle = "rgb(200, 200, 200)"
    ctx.fillText("Start", legendX + 15, legendY + 32)

    ctx.fillStyle = "rgb(239, 68, 68)"
    ctx.beginPath()
    ctx.arc(legendX + 5, legendY + 50, 3, 0, Math.PI * 2)
    ctx.fill()
    ctx.fillStyle = "rgb(200, 200, 200)"
    ctx.fillText("End", legendX + 15, legendY + 54)

    ctx.fillStyle = "rgb(249, 115, 22)"
    ctx.beginPath()
    ctx.arc(legendX + 5, legendY + 72, 3, 0, Math.PI * 2)
    ctx.fill()
    ctx.fillStyle = "rgb(200, 200, 200)"
    ctx.fillText("Current", legendX + 15, legendY + 76)

    ctx.fillStyle = "rgb(59, 130, 246)"
    ctx.fillRect(legendX, legendY + 88, 8, 8)
    ctx.fillStyle = "rgb(200, 200, 200)"
    ctx.fillText("Route", legendX + 15, legendY + 96)

    // Request animation frame for pulse effect
    requestAnimationFrame(() => {})
  }, [tripData, currentLat, currentLng])

  return (
    <div ref={containerRef} className="w-full h-full rounded-lg overflow-hidden border border-border bg-slate-950">
      <canvas ref={canvasRef} className="w-full h-full" />
    </div>
  )
}
