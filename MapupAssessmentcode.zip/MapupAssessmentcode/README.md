# Fleet Tracking Dashboard

A production-ready React + Next.js web application for visualizing and simulating fleet vehicle trips in real-time.

## Features

- **Real-time Trip Simulation**: Animate vehicle positions based on event timestamps
- **Interactive Map**: Visualize trip routes using Leaflet
- **Trip Management**: Select from 5 pre-loaded demo trips
- **Playback Controls**: Play/Pause and adjustable speed (1x, 5x, 10x)
- **Trip Metrics**: View distance, fuel consumption, average speed, and event timelines
- **Responsive Design**: Works on desktop and mobile devices
- **Status Tracking**: Monitor trip status (active, completed, cancelled)

## Tech Stack

- React 19.2
- Next.js 16 (App Router)
- TypeScript
- Tailwind CSS v4
- Leaflet + react-leaflet for mapping
- Shadcn/ui components

## Project Structure

\`\`\`
fleet-tracking-dashboard/
├── public/
│   └── data/
│       ├── trip_1_cross_country.json
│       ├── trip_2_urban_dense.json
│       ├── trip_3_mountain_cancelled.json
│       ├── trip_4_southern_technical.json
│       └── trip_5_regional_logistics.json
├── app/
│   ├── components/
│   │   ├── TripList.tsx          # Trip selector sidebar
│   │   ├── TripMap.tsx           # Leaflet map visualization
│   │   └── TripDetails.tsx       # Trip metrics and event feed
│   ├── hooks/
│   │   └── useSimulator.ts       # Real-time simulation logic
│   ├── utils/
│   │   └── parser.ts            # JSON parsing and data transformation
│   ├── page.tsx                 # Main dashboard layout
│   ├── layout.tsx               # Root layout
│   └── globals.css              # Global styles
├── package.json
├── tsconfig.json
└── README.md
\`\`\`

## Installation & Setup

### Prerequisites
- Node.js 18+
- npm or yarn

### Local Development

1. **Clone and install dependencies:**
   \`\`\`bash
   git clone <your-repo-url>
   cd fleet-tracking-dashboard
   npm install
   \`\`\`

2. **Install additional dependencies:**
   \`\`\`bash
   npm install leaflet react-leaflet lucide-react
   \`\`\`

3. **Run development server:**
   \`\`\`bash
   npm run dev
   \`\`\`

4. **Open browser:**
   Navigate to `http://localhost:3000`

## Usage

1. **Select a Trip**: Click on any trip in the left sidebar
2. **Start Simulation**: Click the Play button to animate vehicle movement
3. **Adjust Speed**: Use the 1x, 5x, 10x buttons to change playback speed
4. **View Details**: Check the right panel for trip metrics and event log
5. **Reset**: Use the reset button to restart the simulation

## Data Structure

Each trip JSON file contains:
- Trip metadata (ID, name, vehicle ID, status)
- Route events with timestamps and coordinates
- Event types: `trip_start`, `trip_end`, `stop`, `delivery`, `alert`, `incident`

Example event:
\`\`\`json
{
  "timestamp": "2024-01-15T08:00:00Z",
  "type": "stop",
  "lat": 40.7128,
  "lng": -74.0060,
  "event_text": "Fuel stop in New York"
}
\`\`\`

## Integration with Live Data

### WebSocket Integration
To replace fallback data with live updates:

\`\`\`typescript
// In useSimulator.ts
const socket = new WebSocket('wss://api.example.com/trips/live')
socket.on('event', (event) => {
  processEvent(event)
})
\`\`\`

### REST API Polling
Or use polling for periodic updates:

\`\`\`typescript
setInterval(async () => {
  const response = await fetch('/api/trips/current-event')
  const event = await response.json()
  processEvent(event)
}, 1000 / state.speed)
\`\`\`

### Backend Requirements
Your backend should provide:
- GET `/api/trips` - List all trips
- GET `/api/trips/{id}` - Get trip details
- GET `/api/trips/{id}/events` - Get events for a trip (supports pagination)
- WebSocket `/ws/trips/{id}` - Stream live events

## Deployment to Vercel

1. **Push to GitHub:**
   \`\`\`bash
   git add .
   git commit -m "Initial commit"
   git push origin main
   \`\`\`

2. **Connect to Vercel:**
   - Go to [vercel.com](https://vercel.com)
   - Click "Add New" → "Project"
   - Select your GitHub repository
   - Vercel auto-detects Next.js and configures settings

3. **Deploy:**
   - Click "Deploy"
   - Your app will be live at `https://<your-project>.vercel.app`

4. **Environment Variables (if needed):**
   - In Vercel Dashboard → Settings → Environment Variables
   - Add any backend API URLs or API keys

## Performance Considerations

- **Incremental Event Processing**: Events are processed one at a time during simulation, not reprocessed each frame
- **Efficient State Updates**: Uses React hooks and requestAnimationFrame for smooth 60fps animation
- **Lazy Loading**: Trip data is loaded on-demand when selected
- **Map Optimization**: Leaflet renders efficiently with vector tiles from OSM

## Browser Support

- Chrome/Edge 90+
- Firefox 88+
- Safari 14+
- Mobile browsers (iOS Safari, Chrome Android)

## License

MIT

## Notes for Code Review

This dashboard is designed to showcase:
- Component composition and reusability
- Custom React hooks for state management
- Integration with mapping libraries
- Real-time data visualization
- TypeScript type safety
- Responsive design patterns
- Clean code architecture

The codebase is structured for easy extension with live data sources or additional features like user authentication, data export, or advanced analytics.
